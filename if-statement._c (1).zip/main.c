/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int n;
    scanf("%d",&n);
    
    if(n%5==0){
        printf("Divisible by 5:");
    }
    
    
else{
printf("not divisible by 5: ");
}


    return 0;
}
